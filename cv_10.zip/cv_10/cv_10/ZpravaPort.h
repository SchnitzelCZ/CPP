#ifndef ZPRAVAPORT_H
#define ZPRAVAPORT_H
#include "Zprava.h"
#include "ASitovyPrvek.h"
struct ZpravaPort {
	Zprava* zprava;
	ASitovyPrvek* port;
	ZpravaPort() { }
	ZpravaPort(Zprava* zprava, ASitovyPrvek* port) : zprava(zprava), port(port) {
	}
};
#endif // !ZPRAVAPORT_H
