#ifndef  UZEL_H
#define UZEL_H
#include "ASitovyPrvek.h"

struct Hub:ASitovyPrvek
{
private:
	string adresa;
	ASitovyPrvek* pripojenyPrvek;
	Fronta<Zprava*> odchoziZpravy;
	void ZpracujPrichoziZpravu(ZpravaPort zp);
public:
	void Pripoj(ASitovyPrvek* sitovyPrvek);
	void Provadej();
	void PripravZpravuKOdeslani(string cil, string obsah);
};

#endif // ! UZEL_H