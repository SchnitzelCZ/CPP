#ifndef  ASITOVYPRVEK_H
#define ASITOVYPRVEK_H
#include "Fronta.h"
#include "ZpravaPort.h"

struct ASitovyPrvek {
protected: 
	Fronta<ZpravaPort> prichoziZpravy;
public:
	void VlozPrichoziZpravu(Zprava* zprava, ASitovyPrvek* port);
	virtual void Provadej();
	virtual void Pripoj(ASitovyPrvek* sitovyPrvek);
	virtual void ZpracujPrichoziZpravu(ZpravaPort zp);


};
#endif // ! ASITOVYPRVEK_H