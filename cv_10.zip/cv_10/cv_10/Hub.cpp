#include "Hub.h"

void Hub::ZpracujPrichoziZpravu(ZpravaPort zp) {
	if(!zpracovaneZpravy.Obsahuje(zp.zprava))
	{
		for (int i = 0; i < maximumPripojenychZarizeni; i++) {
			if (pripojenePrvky[i] != nullptr && pripojenePrvky[i].) {
				pripojenePrvky[i]->VlozPrichoziZpravu(zp.zprava, zp.port);
			}
	}
	};
}