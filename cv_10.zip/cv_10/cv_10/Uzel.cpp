#include "Uzel.h"

void Hub::ZpracujPrichoziZpravu(ZpravaPort zp)
{
	if (zp.zprava->adrCil == adresa) {
		cout << zp.zprava->obsah << endl;
		if (zp.zprava->obsah.compare("ping")) {
			odchoziZpravy.Vloz(new Zprava(1, adresa, zp.zprava->adrZdroj, "pong"));
		}
	}
}

void Hub::Pripoj(ASitovyPrvek * sitovyPrvek)
{
	pripojenyPrvek = sitovyPrvek;
}

void Hub::Provadej()
{
	while (!odchoziZpravy.JePrazdna())
	{
		pripojenyPrvek->VlozPrichoziZpravu(odchoziZpravy.Odeber(), pripojenyPrvek);
		
	}
	/*
	while (!prichoziZpravy.JePrazdna())
	{
		prichoziZpravy.ZpracujPrvky(ZpracujPrichoziZpravu());
	}*/
}

void Hub::PripravZpravuKOdeslani(string cil, string obsah)
{
	odchoziZpravy.Vloz(new Zprava(1,adresa,cil,obsah));
}
