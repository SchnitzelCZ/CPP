#ifndef  HUB_H
#define HUB_H
#include "ASitovyPrvek.h"

struct Hub:ASitovyPrvek
{
private:
	ASitovyPrvek** pripojenePrvky;
	int maximumPripojenychZarizeni;
	Fronta<Zprava*> zpracovaneZpravy;
	void ZpracujPrichoziZpravu(ZpravaPort zp);
public:
	void Pripoj(ASitovyPrvek* sitovyPrvek);
	void Provadej();
};

#endif // ! HUB_H